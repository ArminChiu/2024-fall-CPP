            
            
            
            int x[-3];

/*
4:16: size of array 'x' is not positive
Semantic failed. Exiting.
*/