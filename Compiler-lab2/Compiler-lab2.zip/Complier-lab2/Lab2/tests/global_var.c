int x = 3;

void main()
{
	output_var = x;
	output();
}

/*
output:3
*/