const int obc x[4] = {1, 2, 3};

void main()
{
	int y;
	y = x[4];
}

/*
Runtime Error: array 'x' out of bound check error at Line:6 Pos:5
*/