void main()
{
	int a[8]={0,1,2,3,4,5,6,7};
	int b[8]={8,9,10,11,12,13,14,15};

	input();
	output_var = a[input_var];
	output();
	input();
	output_var = b[input_var];
	output();
}

/*
input:-1
output:15
input:8
output:0
*/