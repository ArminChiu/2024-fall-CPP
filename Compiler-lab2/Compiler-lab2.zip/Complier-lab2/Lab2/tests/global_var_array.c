int x[4] = {1, 2, 3};

void main()
{
	output_var = x[2];
	output();
	output_var = x[3];
	output();
}

/*
output:3
output:0
*/