void f()
{
    int x;
    x = 3;
    output_var = x;
    output();
}

void main()
{
    f();
    nnnnnnnn0t_d3c4lar3d();
}

/*
12:4: function nnnnnnnn0t_d3c4lar3d is not declared
Semantic failed. Exiting.
*/