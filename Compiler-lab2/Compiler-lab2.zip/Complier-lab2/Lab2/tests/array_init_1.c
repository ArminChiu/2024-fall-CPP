void main()
{
    int x[-1+4] = {2, 1};
    output_var = x[0];
    output();
    output_var = x[1];
    output();
    output_var = x[2];
    output();
}

/*
output:2
output:1
output:0
*/