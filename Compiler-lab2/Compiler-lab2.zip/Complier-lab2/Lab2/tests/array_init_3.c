int m;
int n;

void main()
{
    int a = 7, b = -8, c = +0x11;

    m = 3*0x13/11+34-78+0x111;
    n = a*b/c + a*c/b + b*c/a;

    
    int obc x[] = {-3154, m, n, m+n, m-n, +3154, m*n, m/n, m%(-n), 3154};
    input();
    output_var = x[input_var];
    output();
}

/*
input:0
output:-3154
*/
/*
input:1
output:234
*/
/*
input:2
output:-36
*/
/*
input:3
output:198
*/
/*
input:4
output:270
*/
/*
input:5
output:3154
*/
/*
input:6
output:-8424
*/
/*
input:7
output:-6
*/
/*
input:8
output:18
*/
/*
input:9
output:3154
*/
/*
input:-1
Runtime Error: array 'x' out of bound check error at Line:14 Pos:17
*/
/*
input:10
Runtime Error: array 'x' out of bound check error at Line:14 Pos:17
*/