int x[2] = {1, 2, 3};

/*
1:4: excess elements in the initializer of array 'x'
Semantic failed. Exiting.
*/