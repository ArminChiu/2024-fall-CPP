/*
Place Your SafeCIRBuilder Implementation Here
*/