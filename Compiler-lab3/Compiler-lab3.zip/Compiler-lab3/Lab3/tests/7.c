void func()
{
    int a = arg0;
    int obc x[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

    a = arg0*2+1;

    output_var = x[a]; // a = [1]
    output();
}

void main() {
}
