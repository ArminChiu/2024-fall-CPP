// handle the case of a loop

void main()
{
    int idx = -1;
    int a = 4;
    int b = 20;
    int obc x[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

    while (a > 0)
    {
        a = a - 1;
        b = b - 2;
    }

    idx = b;

	output_var = x[idx];    // idx = TOP
	output();
}
