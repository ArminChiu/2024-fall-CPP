void main()
{
    int cond = 0x13;
    int a = 0;
    int obc x[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

    if(cond % 2 != 1)
    {
        a = 1337;
    }

    output_var = x[a];  // a = [0, 1337]
    output();
}
