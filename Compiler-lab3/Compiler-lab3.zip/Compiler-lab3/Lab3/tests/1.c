int ga = 7;

void main()
{
    int idx = -1;
	int a = 0;
	int obc x[8] = {0, 1, 2, 3, 4, 5, 6, 7};

	idx = a;
	output_var = x[idx];    // idx = [0]
	output();

	idx = ga;
	output_var = x[idx];    // idx = [7]
	output();
}